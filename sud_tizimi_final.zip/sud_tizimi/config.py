# config.py
import os

# Railway Variables dan o'qiydi, lokal testda to'g'ridan-to'g'ri yozing
BOT_TOKEN = os.environ.get("BOT_TOKEN", "7543219876:AAH_ExampleTokenHere_YOUR_BOT_TOKEN")
ADMIN_ID  = int(os.environ.get("ADMIN_ID", "123456789"))
